import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingDown, ExternalLink, Bell, BellOff } from "lucide-react";
import { Card } from "@/components/ui/card";
import PriceChart from "./PriceChart";

interface Product {
  id: string;
  name: string;
  currentPrice: number;
  targetPrice: number;
  originalPrice: number;
  lastUpdated: Date;
  imageUrl: string;
  platform: string;
  priceHistory: number[];
  alertActive: boolean;
}

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const priceDrop = product.originalPrice - product.currentPrice;
  const percentDrop = ((priceDrop / product.originalPrice) * 100).toFixed(1);
  const isTargetMet = product.currentPrice <= product.targetPrice;

  return (
    <Card className="overflow-hidden shadow-card border-border hover:shadow-elegant transition-all duration-300 bg-card">
      <div className="relative">
        <img 
          src={product.imageUrl} 
          alt={product.name}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-3 right-3">
          {isTargetMet ? (
            <Badge className="bg-gradient-success text-success-foreground border-0 shadow-sm">
              Target Met!
            </Badge>
          ) : (
            <Badge variant="secondary" className="bg-card/90 backdrop-blur-sm">
              {product.platform}
            </Badge>
          )}
        </div>
      </div>
      
      <div className="p-5 space-y-4">
        <div>
          <h3 className="font-semibold text-foreground text-lg line-clamp-2 mb-2">
            {product.name}
          </h3>
          
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-3xl font-bold text-foreground">
              ${product.currentPrice}
            </span>
            <span className="text-sm text-muted-foreground line-through">
              ${product.originalPrice}
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="flex items-center text-success text-sm font-medium">
              <TrendingDown className="h-4 w-4 mr-1" />
              {percentDrop}% off
            </div>
            <span className="text-sm text-muted-foreground">
              • Target: ${product.targetPrice}
            </span>
          </div>
        </div>

        <div className="h-24">
          <PriceChart data={product.priceHistory} />
        </div>

        <div className="flex gap-2 pt-2">
          <Button variant="outline" size="sm" className="flex-1">
            {product.alertActive ? (
              <>
                <Bell className="h-4 w-4 mr-1" />
                Alert On
              </>
            ) : (
              <>
                <BellOff className="h-4 w-4 mr-1" />
                Alert Off
              </>
            )}
          </Button>
          <Button size="sm" className="flex-1 bg-gradient-primary text-primary-foreground hover:opacity-90">
            View Deal
            <ExternalLink className="h-4 w-4 ml-1" />
          </Button>
        </div>

        <div className="text-xs text-muted-foreground pt-2 border-t border-border">
          Last updated: {product.lastUpdated.toLocaleTimeString()}
        </div>
      </div>
    </Card>
  );
};

export default ProductCard;
