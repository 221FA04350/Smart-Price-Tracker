import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Link, Sparkles } from "lucide-react";

interface AddProductModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AddProductModal = ({ isOpen, onClose }: AddProductModalProps) => {
  const [url, setUrl] = useState("");
  const [targetPrice, setTargetPrice] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Product Added!",
        description: "We'll notify you when the price drops below your target.",
      });
      setIsLoading(false);
      setUrl("");
      setTargetPrice("");
      onClose();
    }, 1500);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <div className="h-8 w-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <Sparkles className="h-5 w-5 text-primary-foreground" />
            </div>
            Track New Product
          </DialogTitle>
          <DialogDescription>
            Paste a product URL and set your target price. We'll monitor it 24/7.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
          <div className="space-y-2">
            <Label htmlFor="url" className="text-base font-semibold">
              Product URL
            </Label>
            <div className="relative">
              <Link className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
              <Input
                id="url"
                type="url"
                placeholder="https://amazon.com/product/..."
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="pl-10"
                required
              />
            </div>
            <p className="text-sm text-muted-foreground">
              Supports Amazon, Walmart, Best Buy, and more
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="targetPrice" className="text-base font-semibold">
              Target Price ($)
            </Label>
            <Input
              id="targetPrice"
              type="number"
              step="0.01"
              placeholder="299.99"
              value={targetPrice}
              onChange={(e) => setTargetPrice(e.target.value)}
              required
            />
            <p className="text-sm text-muted-foreground">
              You'll get an alert when the price drops to or below this amount
            </p>
          </div>

          <div className="flex gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-elegant"
              disabled={isLoading}
            >
              {isLoading ? "Adding..." : "Start Tracking"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddProductModal;
