import { Line, LineChart, ResponsiveContainer, YAxis } from "recharts";

interface PriceChartProps {
  data: number[];
}

const PriceChart = ({ data }: PriceChartProps) => {
  const chartData = data.map((price, index) => ({
    index,
    price,
  }));

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={chartData}>
        <YAxis hide domain={['dataMin - 20', 'dataMax + 20']} />
        <Line
          type="monotone"
          dataKey="price"
          stroke="hsl(var(--success))"
          strokeWidth={2}
          dot={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
};

export default PriceChart;
