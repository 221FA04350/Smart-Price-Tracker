import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Plus, TrendingDown, Bell, BarChart3 } from "lucide-react";
import { Link } from "react-router-dom";
import ProductCard from "@/components/ProductCard";
import AddProductModal from "@/components/AddProductModal";

// Mock data for demonstration
const mockProducts = [
  {
    id: "1",
    name: "Sony WH-1000XM5 Wireless Headphones",
    currentPrice: 349.99,
    targetPrice: 299.99,
    originalPrice: 399.99,
    lastUpdated: new Date(),
    imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400",
    platform: "Amazon",
    priceHistory: [399.99, 379.99, 359.99, 349.99],
    alertActive: true,
  },
  {
    id: "2",
    name: "Apple AirPods Pro (2nd Generation)",
    currentPrice: 199.99,
    targetPrice: 199.99,
    originalPrice: 249.99,
    lastUpdated: new Date(),
    imageUrl: "https://images.unsplash.com/photo-1606841837239-c5a1a4a07af7?w=400",
    platform: "Best Buy",
    priceHistory: [249.99, 229.99, 209.99, 199.99],
    alertActive: true,
  },
  {
    id: "3",
    name: "Samsung Galaxy Watch 6",
    currentPrice: 279.99,
    targetPrice: 249.99,
    originalPrice: 329.99,
    lastUpdated: new Date(),
    imageUrl: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=400",
    platform: "Samsung",
    priceHistory: [329.99, 309.99, 289.99, 279.99],
    alertActive: false,
  },
];

const Dashboard = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [products] = useState(mockProducts);

  const activeAlerts = products.filter(p => p.alertActive).length;
  const totalSavings = products.reduce((acc, p) => acc + (p.originalPrice - p.currentPrice), 0);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <nav className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-xl bg-gradient-primary flex items-center justify-center">
                <TrendingDown className="h-6 w-6 text-primary-foreground" />
              </div>
              <span className="text-2xl font-bold text-foreground">PriceTrack AI</span>
            </Link>
            <Button onClick={() => setIsModalOpen(true)} className="bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-elegant">
              <Plus className="mr-2 h-5 w-5" />
              Track Product
            </Button>
          </nav>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-card p-6 rounded-xl shadow-card border border-border">
            <div className="flex items-center justify-between mb-4">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <BarChart3 className="h-6 w-6 text-primary" />
              </div>
            </div>
            <div className="text-3xl font-bold text-foreground mb-1">{products.length}</div>
            <div className="text-sm text-muted-foreground">Products Tracked</div>
          </div>

          <div className="bg-card p-6 rounded-xl shadow-card border border-border">
            <div className="flex items-center justify-between mb-4">
              <div className="h-12 w-12 rounded-lg bg-success/10 flex items-center justify-center">
                <TrendingDown className="h-6 w-6 text-success" />
              </div>
            </div>
            <div className="text-3xl font-bold text-foreground mb-1">${totalSavings.toFixed(2)}</div>
            <div className="text-sm text-muted-foreground">Total Savings</div>
          </div>

          <div className="bg-card p-6 rounded-xl shadow-card border border-border">
            <div className="flex items-center justify-between mb-4">
              <div className="h-12 w-12 rounded-lg bg-destructive/10 flex items-center justify-center">
                <Bell className="h-6 w-6 text-destructive" />
              </div>
            </div>
            <div className="text-3xl font-bold text-foreground mb-1">{activeAlerts}</div>
            <div className="text-sm text-muted-foreground">Active Alerts</div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold text-foreground">Your Tracked Products</h2>
          </div>
          
          {products.length === 0 ? (
            <div className="bg-card p-12 rounded-xl shadow-card border border-border text-center">
              <TrendingDown className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">No products tracked yet</h3>
              <p className="text-muted-foreground mb-6">Start tracking products to get price alerts and insights</p>
              <Button onClick={() => setIsModalOpen(true)} className="bg-gradient-primary text-primary-foreground hover:opacity-90">
                <Plus className="mr-2 h-5 w-5" />
                Add Your First Product
              </Button>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>

      <AddProductModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
};

export default Dashboard;
