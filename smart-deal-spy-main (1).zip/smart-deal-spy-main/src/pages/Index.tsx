import { Button } from "@/components/ui/button";
import { ArrowRight, TrendingDown, Bell, Sparkles, Target, Zap } from "lucide-react";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-image.jpg";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <nav className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-xl bg-gradient-primary flex items-center justify-center">
              <TrendingDown className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="text-2xl font-bold text-foreground">PriceTrack AI</span>
          </div>
          <Link to="/dashboard">
            <Button variant="outline" size="lg">
              Dashboard
            </Button>
          </Link>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 md:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border shadow-card">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-foreground">AI-Powered Price Intelligence</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-foreground leading-tight">
              Never Miss a
              <span className="bg-gradient-primary bg-clip-text text-transparent"> Deal </span>
              Again
            </h1>
            
            <p className="text-xl text-muted-foreground max-w-xl">
              Track prices across multiple platforms, get instant alerts on price drops, and let AI predict the perfect time to buy.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/dashboard">
                <Button size="lg" className="bg-gradient-primary text-primary-foreground hover:opacity-90 transition-opacity shadow-elegant text-lg px-8">
                  Start Tracking Free
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="text-lg px-8">
                Watch Demo
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-4">
              <div>
                <div className="text-3xl font-bold text-foreground">10K+</div>
                <div className="text-sm text-muted-foreground">Products Tracked</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-foreground">$2M+</div>
                <div className="text-sm text-muted-foreground">Saved by Users</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-foreground">98%</div>
                <div className="text-sm text-muted-foreground">Success Rate</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-primary opacity-20 blur-3xl rounded-full"></div>
            <img 
              src={heroImage} 
              alt="PriceTrack AI Dashboard"
              className="relative rounded-2xl shadow-elegant border border-border"
            />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Intelligent Price Tracking
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Powered by advanced AI to ensure you always get the best deals
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-card p-8 rounded-2xl shadow-card border border-border hover:shadow-elegant transition-all duration-300">
            <div className="h-12 w-12 rounded-xl bg-gradient-primary flex items-center justify-center mb-6">
              <TrendingDown className="h-6 w-6 text-primary-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-3">Real-Time Monitoring</h3>
            <p className="text-muted-foreground">
              Track prices across Amazon, Walmart, Best Buy, and more. Get updates every hour automatically.
            </p>
          </div>

          <div className="bg-card p-8 rounded-2xl shadow-card border border-border hover:shadow-elegant transition-all duration-300">
            <div className="h-12 w-12 rounded-xl bg-gradient-success flex items-center justify-center mb-6">
              <Bell className="h-6 w-6 text-success-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-3">Smart Alerts</h3>
            <p className="text-muted-foreground">
              Receive instant notifications when prices drop below your target. Never miss a deal.
            </p>
          </div>

          <div className="bg-card p-8 rounded-2xl shadow-card border border-border hover:shadow-elegant transition-all duration-300">
            <div className="h-12 w-12 rounded-xl bg-gradient-primary flex items-center justify-center mb-6">
              <Target className="h-6 w-6 text-primary-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-3">AI Predictions</h3>
            <p className="text-muted-foreground">
              Machine learning predicts optimal purchase timing based on historical trends and patterns.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="bg-gradient-primary rounded-3xl p-12 md:p-16 text-center shadow-elegant">
          <Zap className="h-16 w-16 text-primary-foreground mx-auto mb-6" />
          <h2 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-6">
            Ready to Save Smarter?
          </h2>
          <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
            Join thousands of smart shoppers who never overpay. Start tracking your favorite products today.
          </p>
          <Link to="/dashboard">
            <Button size="lg" variant="secondary" className="text-lg px-8 shadow-lg">
              Get Started Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="container mx-auto px-4 py-12 border-t border-border">
        <div className="text-center text-muted-foreground">
          <p>© 2025 PriceTrack AI. Track smarter, save more.</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
